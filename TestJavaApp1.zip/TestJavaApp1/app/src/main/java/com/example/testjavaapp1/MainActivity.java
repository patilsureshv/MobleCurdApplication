package com.example.testjavaapp1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btnSave,btnView,btnUpdate,btnDelete;
    EditText txtName, txtUserName, txtPassword;
    database d;
    SQLiteDatabase db;
    GridView gv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        d = new database(this);
        //db = d.getReadableDatabase();
        ArrayList<String> playres= new ArrayList<String>();
        ArrayAdapter<String> adapter;

        txtName= findViewById(R.id.txtName);
        txtUserName= findViewById(R.id.txtUserName);
        txtPassword= findViewById(R.id.txtPassword);
        btnSave= findViewById(R.id.btnSave);
        btnView= findViewById(R.id.btnView);
        btnUpdate= findViewById(R.id.btnUpdate);
        btnDelete= findViewById(R.id.btnDelete);
        gv= findViewById(R.id.grid);
        adapter= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,playres);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= txtName.getText().toString();
                String username= txtUserName.getText().toString();
                String password= txtPassword.getText().toString();
                if(name.equals("") || username.equals("") || password.equals("")){
                    Toast.makeText(MainActivity.this,"Enter all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    boolean r =d.insert_data(name,username,password);
                    if(r){
                        Toast.makeText(MainActivity.this,"Successful", Toast.LENGTH_SHORT).show();
                    } else{
                        Toast.makeText(MainActivity.this,"Unsuccessful", Toast.LENGTH_SHORT).show();
                    }
                    txtName.setText("");
                    txtUserName.setText("");
                    txtPassword.setText("");
                }
            }
        });
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor c= d.GetData();
                if(c.getCount()==0){
                    Toast.makeText(MainActivity.this,"No data found", Toast.LENGTH_SHORT).show();
                }
                StringBuffer buffer = new StringBuffer();
                playres.clear();
                while (c.moveToNext()){
                    buffer.append("Name:" + c.getString(0) + "\n");
                    buffer.append("UserName:" + c.getString(1)+ "\n");
                    buffer.append("Password:" + c.getString(2)+ "\n\n\n");
                    playres.add(c.getString(1));
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("User Data");
                builder.setMessage(buffer.toString());
                builder.show();

                gv.setAdapter(adapter);



            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= txtName.getText().toString();
                String username= txtUserName.getText().toString();
                String password= txtPassword.getText().toString();
                if(name.equals("") || username.equals("") || password.equals("")){
                    Toast.makeText(MainActivity.this,"Enter all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    boolean r =d.update_data(name,username,password);
                    if(r){
                        Toast.makeText(MainActivity.this,"Update Successful", Toast.LENGTH_SHORT).show();
                    } else{
                        Toast.makeText(MainActivity.this,"Update Unsuccessful", Toast.LENGTH_SHORT).show();
                    }
                    txtName.setText("");
                    txtUserName.setText("");
                    txtPassword.setText("");
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String name= txtName.getText().toString();
                String username= txtUserName.getText().toString();
                //String password= txtPassword.getText().toString();
                if(username.equals("") ){
                    Toast.makeText(MainActivity.this,"Enter user name", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    boolean r =d.delete_data(username);
                    if(r){
                        Toast.makeText(MainActivity.this,"Delete Successful", Toast.LENGTH_SHORT).show();
                    } else{
                        Toast.makeText(MainActivity.this,"Delete Unsuccessful", Toast.LENGTH_SHORT).show();
                    }
                    txtName.setText("");
                    txtUserName.setText("");
                    txtPassword.setText("");
                }
            }
        });

    }
}